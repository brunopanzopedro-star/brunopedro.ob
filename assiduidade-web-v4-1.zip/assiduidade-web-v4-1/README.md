# Assiduidade QR V4 — aplicação web

## Requisitos
Node.js 20 ou superior; internet para instalar pacotes e carregar a biblioteca de leitura da câmara.

## Instalação local
1. Extraia o ZIP.
2. Abra o terminal na pasta do projecto.
3. Instale: `npm install`
4. Defina as variáveis de ambiente `ADMIN_USER` e `ADMIN_PASSWORD` (senha com pelo menos 12 caracteres). No PowerShell: `$env:ADMIN_USER='admin'` e `$env:ADMIN_PASSWORD='uma-senha-forte-com-16-caracteres'`.
5. Inicie: `npm start`
6. Aceda a `http://localhost:3000` e entre com as credenciais configuradas.

## Publicação online
Hospede num servidor Node.js com armazenamento persistente e HTTPS. Configure `ADMIN_USER`, `ADMIN_PASSWORD`, `PORT` (se necessário) e `DATA_DIR` num volume persistente. Nunca publique a pasta `data` nem as senhas. A leitura pela câmara requer HTTPS fora de localhost.

## Como usar
Administrador: cadastre funcionários e horários, gere QR para um dia ou sete dias, imprima ou guarde os QR gerados, inicie fiscalizações surpresa e exporte CSV. Funcionário: entre com as credenciais e leia o QR do dia para registar entrada; leia novamente para registar saída. Cada QR é válido apenas na sua data, mas pode ser lido por vários funcionários nesse dia. QR já gerado não pode ser recuperado: o servidor guarda apenas o hash; se perdeu o QR, será necessário criar uma função administrativa de revogação/rotação numa versão futura.

## Limitações importantes
Esta é uma versão funcional de testes, NÃO uma implementação auditada para produção. QR diário pode ser fotografado e partilhado. Não há comprovação de presença física; fiscalização surpresa é complementar. A ausência de marcação não é automaticamente falta confirmada. O sistema não inclui ainda calendário de dias de trabalho/feriados, justificações formais, recuperação de senhas, trilha de auditoria completa, 2FA, gestão de permissões granular, rate limit distribuído, backups automáticos, política de retenção nem configuração de proxy HTTPS. A exportação CSV contém apenas registos de marcação, não uma grelha completa de ausências. Para operação real, adicione esses mecanismos, testes de segurança e conformidade de dados pessoais.

## Impressão de QR em PDF (V4.1)
No painel de administrador, seleccione um dia ou sete dias e clique em **Gerar códigos**. Em seguida, clique em **Descarregar QR em PDF (A4 para impressão)**. O PDF contém uma página A4 por dia, com data de validade em destaque, para impressão e colocação na vitrina.

**Importante:** por segurança, o servidor guarda apenas o hash do segredo. O PDF deve ser descarregado imediatamente após a geração; se a data já tiver um QR, o sistema não o recupera. Guarde o PDF em local seguro. A divulgação do QR na vitrina permite fotografá-lo e partilhá-lo; a fiscalização surpresa reduz riscos, mas não comprova presença física. O QR expira à meia-noite de Angola na data indicada.
